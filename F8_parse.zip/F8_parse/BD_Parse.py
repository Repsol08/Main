"""
-*- coding: utf-8 -*-
Title: BD_Wuhan_Education_req.py
Version: 0.1.1
Author: J German
Maintainer: J German
Description: Reads raw POI result files, parses, and appends to csv 
"""

import os
import csv
import time
from datetime import datetime


def BD_Parse(parsetext, wd, outdir, outfile_name):

    for file in os.listdir(wd):
        with open(os.path.join(wd, file), 'r', encoding='utf-8') as f: # Read file
            parsed = f.read().split(parsetext) # Indicate string used to parse content of file

            for key in range(len(parsed)):
                content = parsed[key]

                # Strips extraneous characters from end of value-pairs in raw content files
                res = dict(map(str.strip, sub.split(':', 1)) for sub in content.split(', ') if ':' in sub)
                clean_res = {key.strip('\''): item.strip('}') for key, item in res.items()}
                clean_res = {key.strip('\''): item.strip('\'') for key, item in clean_res.items()}

                # Change value-pair names to match schema field names
                clean_res['FeatureType'] = clean_res.pop('std_tag')
                clean_res['FeatureName'] = clean_res.pop('name')
                clean_res['ADM1'] = clean_res.pop('prov_name')
                clean_res['ADM1_code'] = clean_res.pop('prov_code')
                clean_res['City'] = clean_res.pop('city_name')
                clean_res['Neighborhood'] = clean_res.pop('area_name')
                clean_res['Address'] = clean_res.pop('addr')
                clean_res['Telephone'] = clean_res.pop('tel')

                # Define column headers for outfile.csv
                csv_cols = ['FeatureType', 'FeatureName', 'ADM1', 'ADM1_code', 'City', 'city_code',
                            'Neighborhood', 'Neighborhood_code', 'Address', 'address_norm', 'uid',  'std_tag_id',
                            'di_tag', 'Telephone', 'x', 'y']              

                # Write parsed content row by row to csv
                try:
                    with open(outdir + outfile_name + '.csv', 'w', encoding='utf-8') as csvfile:
                        writer = csv.DictWriter(csvfile, fieldnames=csv_cols, restval='', extrasaction='ignore',
                                                dialect='excel')
                        writer.writeheader()
                        writer.writerow(clean_res)
                        result = 'Initial content has been parsed.'
                except IOError:
                    print("I/O Error")

    return result

class BD_Parser():

    def BD_Parse(self, parsetext, wd, outdir, outfile_name):
        return BD_Parse(parsetext, wd, outdir, outfile_name)
