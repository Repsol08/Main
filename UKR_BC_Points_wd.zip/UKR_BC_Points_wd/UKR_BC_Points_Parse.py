import os
import sys
import json
import csv
import time
from colorama import init
from colorama import Fore, Back, Style
from datetime import datetime
init(autoreset=True)
print("Imports Complete")

def UKR_BC_Parse(wd, file, outdir, outfile_name):
    # Set outfile path
    outfile = os.path.join(outdir + outfile_name)

    # Start timer
    start = time.time()

    with open(os.path.join(wd, file), 'r', encoding='utf-8') as f:
        jdata = json.load(f)
        # print(jdata)
    ft_data = jdata['bc_details']
    # print(ft_data)
    try:
        with open(outfile, 'w', encoding='utf-8') as out_f:
            count = 0
            for ft in ft_data:
                if count ==0:
                    header = ft.keys()
                    writer = csv.writer(out_f)
                    writer.writerow(header)
                    count += 1
                writer.writerow(ft.values())
    except IOError:
        print("I/O Error")
            
    # End timer
    finish = time.time() - start
    print('Script completed in %s' % finish)

if __name__ == '__main__':
    UKR_BC_Parse(r'D:\\Users\\germanjd6049\\Documents\\FH\\Main-main\\F-28\\', 'UKR_EN_Points_Update.json',
             r'D:\\Users\\germanjd6049\\Documents\\FH\\Main-main\\UKR_BC_Points\\', 'UK_EN_Points_Output.csv')